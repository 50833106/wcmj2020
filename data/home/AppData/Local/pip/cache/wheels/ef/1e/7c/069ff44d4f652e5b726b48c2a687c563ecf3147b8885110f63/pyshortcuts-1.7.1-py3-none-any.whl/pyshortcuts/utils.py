#!/usr/bin/env python
"""
deprecated!

utilities for pyshortcuts
"""
__deprecated__ = True
