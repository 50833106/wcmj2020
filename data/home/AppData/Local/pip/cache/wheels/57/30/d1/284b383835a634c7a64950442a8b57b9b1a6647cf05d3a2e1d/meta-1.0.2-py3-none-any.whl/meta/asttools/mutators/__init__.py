'''
Tools to mutate ast nodes.
'''